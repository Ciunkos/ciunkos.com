Mars Napada!
A ty na co czekasz? Wskakuj do czo�gu i bro� naszej planety!

Mars Napada jest to klon znanej chyba wszystkim gry Space Invaders, stworzony na konkurs Classic Compo: Reaktywacja organizowanego przez Vip� (www.vipagames.pl). W grze czeka na ciebie 99 poziom�w, 8 rodzaj�w broni, kt�re przydadz� si� w eksterminacji obcych.
Sterowanie kursory prawo/lewo do poruszania si�, SPACJA to strza�, SHIFT/CTRL/1-8 zmiana broni, Q - spowolnienie czasu, E - tarcza ESC wyj�cie ;)
W grze zosta� u�yty autorski framework, Direct3D i Audiere.
D�wi�ki w wi�kszo�ci pochodz� z www.SoundSnap.com i prawa do nich maj� odpowiedni im autorzy. Animacja eksplozji wygenerowana przez Explosion Generator Cliffa Harrisa.

�YCZ� MI�EJ GRY!
Ciunkos