......:::::::::BLOOP'S ADVENTURES:::::::::......

To gra, mo�na powiedzie�, �e przygod�wka. Czeka na Ciebie 5 poziom�w, zwiedzisz dos�ownie ca�y �wiat :)
Przejedziesz si� na strusiu, zwiedzisz piramidy, posurfujesz na desce, przejedziesz si� w�zkiem kopalnianym, a tak�e po�lizgasz si� po krach lodowcowych. Sterowanie jest opisane przy ka�dej z plansz, kt�r� mo�emy wybra� w menu. W grze pos�ugujemy si� tylko klawiatur� wi�c myszka jest zb�dna. W menu operujemy kursorami i zatwierdzamy wyb�r ENTEREM. Gra mo�e nie jest, a� tak rozbudowana poniewa� po�wi�ci�em wiele czasu na grafik�, kt�r� robi�em sam (99% Paint). Gra u�ywa DirectX i Audiere - oparta na autorskim frameworku.

Uwagi co do wymaga�:
-Gra wymaga DirectX 9.0c
-Gra testowana na Windows XP, Vista i 7.
-Gra na starszych komputerach mo�e wolno si� �adowa�, wi�c nie uciekaj sprzed monitora. Poczekaj chwilk�, a nie po�a�ujesz ;)

W grze zosta�y u�yte d�wi�ki pochodzenia i autor�w:
-Niewymienione - soundsnap.com
-Daler Mehndi - Tunak Tunak Tun
-Lody na Patyku - Skaner
-Cztery razy po dwa razy - Biesiadne
Niestety, tym razem nie mia�em mikrofonu ;(

�YCZ� MI�EJ GRY!
Ciunkos